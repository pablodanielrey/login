

class JSONSerializable:
    pass
