
from wamp_utils.WampComponent import WampComponent
from wamp_utils.JSONSerializable import JSONSerializable

__all__ = [
    'WampComponent',
    'JSONSerializable'
]

def getWampUser(con, details):
    return {
        'id': 'asdsadsa'
    }
