from model_utils import Base

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

engine = create_engine('postgresql://{}:{}@{}:5432/{}'.format(os.environ[
    'LOGIN_DB_USER',
    'LOGIN_DB_PASSWORD'
    'LOGIN_DB_HOST',
    'LOGIN_DB_NAME'
]))

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

from .HttpAuthProvider import HttpAuthProvider

__all__ = [
    'Session'
    'HttpAuthProvider'
]
