
class InvalidTokenException(Exception):
    pass
